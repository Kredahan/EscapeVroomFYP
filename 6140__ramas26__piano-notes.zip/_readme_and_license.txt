Sound pack downloaded from Freesound
----------------------------------------

This pack of sounds contains sounds by the following user:
 - ramas26 ( https://freesound.org/people/ramas26/ )

You can find this pack online at: https://freesound.org/people/ramas26/packs/6140/

License details
---------------

Creative Commons 0: http://creativecommons.org/publicdomain/zero/1.0/


Sounds in this pack
-------------------

  * 95332__ramas26__g.wav
    * url: https://freesound.org/s/95332/
    * license: Creative Commons 0
  * 95331__ramas26__f.wav
    * url: https://freesound.org/s/95331/
    * license: Creative Commons 0
  * 95330__ramas26__e.wav
    * url: https://freesound.org/s/95330/
    * license: Creative Commons 0
  * 95329__ramas26__d.wav
    * url: https://freesound.org/s/95329/
    * license: Creative Commons 0
  * 95328__ramas26__c.wav
    * url: https://freesound.org/s/95328/
    * license: Creative Commons 0
  * 95327__ramas26__b.wav
    * url: https://freesound.org/s/95327/
    * license: Creative Commons 0
  * 95326__ramas26__a.wav
    * url: https://freesound.org/s/95326/
    * license: Creative Commons 0


